#!/bin/bash
java -jar l2jcli.jar